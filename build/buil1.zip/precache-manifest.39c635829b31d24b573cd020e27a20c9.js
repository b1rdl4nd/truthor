self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5b67a7c53e3e82c4d16f977e3f88b043",
    "url": "/truthor/index.html"
  },
  {
    "revision": "2299702f6d357b64eada",
    "url": "/truthor/static/css/main.ba5d363f.chunk.css"
  },
  {
    "revision": "3ebd599c04b5ca61b5af",
    "url": "/truthor/static/js/2.a1c50c1d.chunk.js"
  },
  {
    "revision": "0749163b59fbee32225059cb60c18af6",
    "url": "/truthor/static/js/2.a1c50c1d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2299702f6d357b64eada",
    "url": "/truthor/static/js/main.b1864da3.chunk.js"
  },
  {
    "revision": "45df3f63babfc116f73f",
    "url": "/truthor/static/js/runtime-main.43f5b909.js"
  },
  {
    "revision": "f0d6313e6c1d3b48d892bb7a4b639670",
    "url": "/truthor/static/media/DMMono-Regular.f0d6313e.ttf"
  }
]);